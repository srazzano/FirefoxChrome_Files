(function() { 

  "use strict";

  if (location != "chrome://browser/content/browser.xul") return;

  var {classes: Cc, interfaces: Ci, utils: Cu} = Components;

  const btnLabel = "Tab Close Left",
        btnTipLeft = "Tab Close on Left",
        btnTipRight = "Tab Close on Right",
        pb = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService).QueryInterface(Ci.nsIPrefBranch);

  pref.root = "browser.Tabs_Close_Button.";

  pref.defaults = { onLeft: false }
  var gRoot = pb.getBranch(pref.root);

  for (let key in pref.defaults) {
    if (pref.defaults.hasOwnProperty(key)) {
      let val = pref.defaults[key];
      switch (typeof val) { case "boolean": pb.getDefaultBranch(pref.root).setBoolPref(key, val) }
  } }

  function pref(key) {
    let {branch, defaults} = pref;
    if (branch == null) branch = pb.getBranch(pref.root);
    switch (typeof defaults[key]) { case "boolean": return branch.getBoolPref(key) }
    return null;
  }

  function setCloseLeft() {
    if (pref("onLeft")) document.getElementById("main-window").setAttribute("close-left", true);
    else document.getElementById("main-window").removeAttribute("close-left");
  }

  function onClick(e) {
    if (e.button === 0) {
      let bool = pref("onLeft") != true ? true : false;
      gRoot.setBoolPref("onLeft", bool);
      if (bool) document.getElementById("close-left").tooltipText = btnTipRight;
      else document.getElementById("close-left").tooltipText = btnTipLeft;
      setCloseLeft();
    }
    else return;
  }

  setCloseLeft();

  try {
    CustomizableUI.createWidget({
      id: "close-left",
      type: "custom",
      //defaultArea: CustomizableUI.AREA_NAVBAR,
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul", "toolbarbutton");
        toolbaritem.onclick = event => onClick(event);
        var props = {
          id: "close-left",
          class: "toolbarbutton-1 chromeclass-toolbar-additional",
          label: btnLabel,
          tooltiptext: pref("onLeft") ? btnTipRight : btnTipLeft
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
  } catch(e) {};

})();
