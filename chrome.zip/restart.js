(function() { 

  "use strict";

  const aName = Services.appinfo.name,
        aVersion = Services.appinfo.version,
        btnTip = "Restart " + aName + " " + aVersion;

  function restartNow(event) {
    if (event.button === 1) Services.appinfo.invalidateCachesOnRestart();
    else if (event.button === 2) return;
    let cancelQuit = Components.classes["@mozilla.org/supports-PRBool;1"].createInstance(Components.interfaces.nsISupportsPRBool);
    Services.obs.notifyObservers(cancelQuit, "quit-application-requested", "restart");
    if (!cancelQuit.data) Services.startup.quit(Services.startup.eAttemptQuit | Services.startup.eRestart);
  }

  var titlebox = document.getElementById("titlebar-buttonbox"),
      restartbtn = document.createElementNS("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul", "toolbarbutton");
  restartbtn.setAttribute("id", "restart-button");
  restartbtn.setAttribute("class", "titlebar-button");
  restartbtn.setAttribute("tooltiptext", btnTip);
  restartbtn.onclick = event => restartNow(event);
  titlebox.insertBefore(restartbtn, titlebox.firstChild);

})();