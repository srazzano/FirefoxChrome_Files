(function() { 

  "use strict";

  var {classes: Cc, interfaces: Ci, utils: Cu} = Components;

  const btnImage = "list-style-image: url('file:///C:/Firefox Images/launch.png')",
        btnLabel = "Launch App",
        btnTip = "Launch App\n \u2022 Left-click for IMDb\n \u2022 Middle-click for Chrome\n \u2022 Right-click for Microsoft Word\n \u2022 Shift + Left-click for Wordpad\n \u2022 Ctrl + Left-click for WordWeb",
        pb = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService).QueryInterface(Ci.nsIPrefBranch);

  pref.root = "browser.Launch_App.";

  pref.defaults = {
    // Use * after app path to indicate argument/switch
    app1: "https://www.imdb.com",
    app2: "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    app3: "C:\\Program Files (x86)\\Microsoft Office\\Office10\\WINWORD.EXE*/q",
    app4: "C:\\Windows\\System32\\write.exe",
    app5: "C:\\Program Files (x86)\\WordWeb\\wweb32.exe"
  }

  for (let key in pref.defaults) {
    if (pref.defaults.hasOwnProperty(key)) {
      let val = pref.defaults[key];
      switch (typeof val) { case "string": pb.getDefaultBranch(pref.root).setCharPref(key, val) }
  } }

  function pref(key) {
    let {branch, defaults} = pref;
    if (branch == null) branch = pb.getBranch(pref.root);
    switch (typeof defaults[key]) { case "string": return branch.getCharPref(key) }
    return null;
  }

  function launchApp(e) {
    let app = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile),
        pro = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess),
        args, exe, url;
    if (e.button === 0 && !e.shiftKey && !e.ctrlKey && !e.altKey) exe = pref("app1");
    if (e.button === 0 && e.shiftKey && !e.ctrlKey && !e.altKey) exe = pref("app4");
    if (e.button === 0 && !e.shiftKey && e.ctrlKey && !e.altKey) exe = pref("app5");
    if (e.button === 1 && !e.shiftKey && !e.ctrlKey && !e.altKey) exe = pref("app2");
    if (e.button === 2 && !e.shiftKey && !e.ctrlKey && !e.altKey) exe = pref("app3");
    if (exe.match(/^https?/)) {
      gBrowser.selectedTab = gBrowser.addTab(exe);
      return;
    }
    if (exe.indexOf("*") > -1) {
      url = exe.split("*")[0];
      args = [exe.split("*")[1]];
    } else {
      url = exe;
      args = "";
    }
    app.initWithPath(url);
    if (!app.exists()) {
      alert("Couldn't locate executable.");
      return;
    }
    pro.init(app);
    if (e.shiftKey || e.ctrlKey || e.altKey) setTimeout(function() { pro.run(false, args, args.length) }, 500);
    else pro.run(false, args, args.length);
  }

  try {
    CustomizableUI.createWidget({
      id: "launch-app",
      type: "custom",
      onBuild: function(aDoc) {
        var btn = aDoc.createElementNS("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul", "toolbarbutton");
        btn.onclick = event => launchApp(event);
        btn.addEventListener("mouseover", function(){document.getElementById("toolbar-context-menu").hidden = true}, false);
        btn.addEventListener("mouseout", function(){document.getElementById("toolbar-context-menu").hidden = false}, false);
        var props = {
          id: "launch-app",
          class: "toolbarbutton-1 chromeclass-toolbar-additional",
          label: btnLabel,
          tooltiptext: btnTip,
          style: btnImage
        };
        for (var p in props) btn.setAttribute(p, props[p]);
        return btn;
      }
    });
  } catch(e) {};

})();
