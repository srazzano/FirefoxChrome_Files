(function() { 

  "use strict";

  if (location != "chrome://browser/content/browser.xul") return;

  const btnImage = "list-style-image: url('file:///C:/Firefox Images/scroll.png')",
        btnLabel = "Mousewheel Zoom",
        btnTip = "Mousewheel Zoom\n \u2022 Hover button and use mouse wheel to zoom\n \u2022 Left-click to reset zoom";

  function mousewheelMove(e) { e.deltaY < 0 ? zoomOut() : zoomIn() }

  function onClick(e) { if (e.button === 0) zoomNormal() }

  function zoomNormal() { FullZoom.reset() }

  function zoomOut() { FullZoom.reduce() }

  function zoomIn() { FullZoom.enlarge() }

  try {
    CustomizableUI.createWidget({
      id: "scroll-zoom",
      type: "custom",
      onBuild: function(aDoc) {
        let btn = aDoc.createElementNS("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul", "toolbarbutton");
        btn.addEventListener("wheel", function(e) { mousewheelMove(e) }, false);
        btn.onclick = e => onClick(e);
        var props = {
          id: "scroll-zoom",
          class: "toolbarbutton-1 chromeclass-toolbar-additional",
          label: btnLabel,
          tooltiptext: btnTip,
          style: btnImage
        };
        for (var p in props) btn.setAttribute(p, props[p]);
        return btn;
      }
    });
  } catch(e) {};
  
})();
