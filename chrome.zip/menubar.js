(function() { 

  "use strict";

  if (location != "chrome://browser/content/browser.xul") return;

  var menubar = document.getElementById("toolbar-menubar"),
      navbar = document.getElementById("nav-bar");
  navbar.insertBefore(menubar, navbar.firstChild);

})();
