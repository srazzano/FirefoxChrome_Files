(function() { 

  "use strict";

  if (location != "chrome://browser/content/browser.xul") return;

  var {classes: Cc, interfaces: Ci, utils: Cu} = Components;

  const xulns = "http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul",
        pb = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService).QueryInterface(Ci.nsIPrefBranch),
        name = Services.appinfo.name,
        version = Services.appinfo.version,
        profile = Services.dirsvc.get("ProfD", Ci.nsIFile).path.split("\\Profiles\\")[1],
        index = profile.lastIndexOf("."),
        prof = profile.substring(index + 1, 20).trim(),
        btnLabel1 = name + " " + version,
        btnLabel2 = "[" + prof + "]",
        dayOfWeekLong = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
        dayOfWeekShort = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
        monthLong = ['January','February','March','April','May','June','July','August','September','October','November','December'],
        monthShort = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
        monthNum = ['1','2','3','4','5','6','7','8','9','10','11','12'],
        dayOfMonthNum = ['','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'],
        dayOfMonthOrd = ['','1st','2nd','3rd','4th','5th','6th','7th','8th','9th','10th','11th','12th','13th','14th','15th','16th','17th','18th','19th','20th','21st','22nd','23rd','24th','25th','26th','27th','28th','29th','30th','31st'];

  pref.root = "browser.App_Profile_Date.";

  pref.defaults = { timeFormat: 4 }

  for (let key in pref.defaults) {
    if (pref.defaults.hasOwnProperty(key)) {
      let val = pref.defaults[key];
      switch (typeof val) { case "number": pb.getDefaultBranch(pref.root).setIntPref(key, val) }
  } }

  function pref(key) {
    let {branch, defaults} = pref;
    if (branch == null) branch = pb.getBranch(pref.root);
    switch (typeof defaults[key]) { case "number": return branch.getIntPref(key) }
    return null;
  }

  function getDayLong() {
    let date = new Date(),
        weekday = date.getDay();
    return dayOfWeekLong[weekday];
  }

  function getDayShort() {
    let date = new Date(),
        weekday = date.getDay();
    return dayOfWeekShort[weekday];
  }

  function getMonthLong() {
    let date = new Date(),
        month = date.getMonth();
    return monthLong[month];
  }

  function getMonthShort() {
    let date = new Date(),
        month = date.getMonth();
    return monthShort[month];
  }

  function getMonthNum() {
    let date = new Date(),
        month = date.getMonth();
    return monthNum[month];
  }

  function getDayOfMonthNum() {
    let date = new Date(),
        day = date.getDate();
    return dayOfMonthNum[day];
  }

  function getDayOfMonthOrd() {
    let date = new Date(),
        day = date.getDate();
    return dayOfMonthOrd[day];
  }

  function getYearLong() {
    let date = new Date(),
        yearLong = date.getFullYear();
    return yearLong;
  }

  function getYearShort() {
    let date = new Date(),
        yearShort = date.getFullYear() - 2000;
    return yearShort;
  }

  function getTime(num) {
    if (num < 1 || num > 4) return;
    var date = new Date(),
        hour = date.getHours(),
        hour2 = hour,
        minute = date.getMinutes(),
        second = date.getSeconds(),
        timeday;
    if (hour < 12) { timeday = " AM" } else { timeday = " PM" }
    if (hour > 12) { hour = hour - 12 }
    if (hour === 0) { hour = 12 }
    if (hour2 < 10) { hour2 = "0" + hour2 }
    if (minute < 10) { minute = ":0" + minute } else { minute = ":" + minute }
    if (second < 10) { second = ":0" + second } else { second = ":" + second }
    switch (num) {
      case 1: return hour2 + minute;
      case 2: return hour2 + minute + second;
      case 3: return hour + minute + timeday;
      case 4: return hour + minute + second + timeday;
  } }

  function updateTime() {
    let num = pref("timeFormat"),
        fTime = document.getElementById("format-time");
    if (num > 0 && num < 5) {
      fTime.style.display = "-moz-box";
      fTime.label = getTime(num);
    } else fTime.style.display = "none";
  }

  var bool = pref("timeFormat");
  if (bool && bool < 5) {
    setTimeout(function() { updateTime() }, 200);
    if (bool === 1 || bool === 3) setInterval(updateTime, 10000);
    else if (bool === 2 || bool === 4) setInterval(updateTime, 500);
  } else clearInterval(updateTime);

  try {
    CustomizableUI.createWidget({
      id: "bookmark-button",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        toolbaritem.addEventListener("mouseover", function() { 
          SidebarUI.toggle("viewBookmarksSidebar");
        }, false);
        var props = { 
          id: "bookmark-button",
          class: "toolbarbutton-1 chromeclass-toolbar-additional",
          label: "Bookmarks",
          style: "list-style-image: url('file:///C:/Firefox Images/bookmarks.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "app",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "app",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title app",
          label: btnLabel1
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "profile",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "profile",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title profile",
          label: btnLabel2
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "day-long",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "day-long",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-date day",
          label: getDayLong()
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "day-short",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "day-short",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-date day",
          label: getDayShort()
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "month-long",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "month-long",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-date month",
          label: getMonthLong()
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "month-short",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "month-short",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-date month",
          label: getMonthShort()
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "month-num",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "month-num",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-date month",
          label: getMonthNum()
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "week-num",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "week-num",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-date weekday",
          label: getDayOfMonthNum()
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "week-ord",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "week-ord",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-date weekday",
          label: getDayOfMonthOrd()
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "year-long",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "year-long",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-date year",
          label: getYearLong()
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "year-short",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "year-short",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-date year",
          label: getYearShort()
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "format-time",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "format-time",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-time"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer1",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer1",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer separator",
          label: "separator1",
          style: "list-style-image: url('file:///C:/Firefox Images/separator1.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer2",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer2",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer separator",
          label: "separator2",
          style: "list-style-image: url('file:///C:/Firefox Images/separator2.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer3",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer3",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer separator",
          label: "separator3",
          style: "list-style-image: url('file:///C:/Firefox Images/separator3.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer4",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer4",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer bullet",
          label: "bullet1",
          style: "list-style-image: url('file:///C:/Firefox Images/bullet1.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer5",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer5",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer bullet",
          label: "bullet2",
          style: "list-style-image: url('file:///C:/Firefox Images/bullet2.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer6",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer6",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer bullet",
          label: "bullet3",
          style: "list-style-image: url('file:///C:/Firefox Images/bullet3.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer7",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer7",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer dash",
          label: "dash1",
          style: "list-style-image: url('file:///C:/Firefox Images/dash1.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer8",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer8",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer dash",
          label: "dash2",
          style: "list-style-image: url('file:///C:/Firefox Images/dash2.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer9",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer9",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer dash",
          label: "dash3",
          style: "list-style-image: url('file:///C:/Firefox Images/dash3.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer10",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer10",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer slash",
          label: "slash1",
          style: "list-style-image: url('file:///C:/Firefox Images/slash1.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer11",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer11",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer slash",
          label: "slash2",
          style: "list-style-image: url('file:///C:/Firefox Images/slash2.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-spacer12",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-spacer12",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer slash",
          label: "slash3",
          style: "list-style-image: url('file:///C:/Firefox Images/slash3.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-comma1",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-comma1",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer comma",
          label: "comma1",
          style: "list-style-image: url('file:///C:/Firefox Images/comma1.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-comma2",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-comma2",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer comma",
          label: "comma2",
          style: "list-style-image: url('file:///C:/Firefox Images/comma2.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-comma3",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-comma3",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer comma",
          label: "comma3",
          style: "list-style-image: url('file:///C:/Firefox Images/comma3.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-period1",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-period1",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer period",
          label: "period1",
          style: "list-style-image: url('file:///C:/Firefox Images/period1.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-period2",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-period2",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer period",
          label: "period2",
          style: "list-style-image: url('file:///C:/Firefox Images/period2.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
    CustomizableUI.createWidget({
      id: "title-period3",
      type: "custom",
      onBuild: function(aDocument) {
        var toolbaritem = aDocument.createElementNS(xulns, "toolbarbutton");
        var props = {
          id: "title-period3",
          class: "toolbarbutton-1 chromeclass-toolbar-additional title-spacer period",
          label: "period3",
          style: "list-style-image: url('file:///C:/Firefox Images/period3.png')"
        };
        for (var p in props) toolbaritem.setAttribute(p, props[p]);
        return toolbaritem;
      }
    });
  } catch(e) {};

})();
