(function() {

  "use strict";

  var {classes: Cc, interfaces: Ci, utils: Cu} = Components;

  const btnLabel = "Who Is",
        btnTip = "WHOIS Search for Active Tab URL Domain",
        btnImage = "list-style-image: url('file:///C:/Firefox Images/whois.png')",
        siteDomain = true,
        webPage = "https://www.whois.com/whois/",
        eTLD = Cc["@mozilla.org/network/effective-tld-service;1"].getService(Ci.nsIEffectiveTLDService);

  function whoIs(e) {
    if (e.button === 0 && !e.shiftKey && !e.ctrlKey && !e.altKey) {
      if (location != "chrome://browser/content/browser.xul") return;
      let uri = gBrowser.currentURI.host, 
          etl;
      try {
        etl = eTLD.getBaseDomain(uri);
      } catch(ex) {etl = uri}
      let domain = siteDomain ? etl : uri;
      gBrowser.selectedTab = gBrowser.addTab(webPage + domain);
  } }

  try {
    CustomizableUI.createWidget({
      id: "whois-button",
      type: "custom",
      onBuild: function(aDoc) {
        var btn = aDoc.createElementNS("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul", "toolbarbutton");
        btn.onclick = event => whoIs(event);
        var props = {
          id: "whois-button",
          class: "toolbarbutton-1 chromeclass-toolbar-additional",
          label: btnLabel,
          tooltiptext: btnTip,
          style: btnImage
        };
        for (var p in props) btn.setAttribute(p, props[p]);
        return btn;
      }
    });
  } catch(e) {};

})();
