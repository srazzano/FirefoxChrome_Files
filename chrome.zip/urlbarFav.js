(function() { 

  "use strict";

  if (location != "chrome://browser/content/browser.xul") return;

  var throbber = true;

  const cbFav = "file:///C:/Firefox Images/cb.png",
        usoFav = "file:///C:/Firefox Images/uso.png",
        noFav = "file:///C:/Firefox Images/nofav.png",
        configFav = "file:///C:/Firefox Images/config.png",
        throbberFav = "file:///C:/Firefox Images/throbber.png";

  try {
    let identityBox = document.getElementById("identity-box"),
        boxImg = document.createElementNS("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul", "image");
    boxImg.setAttribute("id", "sitefavinurl-image");
    identityBox.insertBefore(boxImg, identityBox.firstChild);
  } catch(ex) {}

  function loadFavs() {
    try {
      var favImage = document.getElementById("sitefavinurl-image"),
          tabs = document.getElementsByTagName("tab"),
          tabImg = gBrowser.selectedTab;
      for (var i = 0; i < tabs.length; i++) {
        if (tabs[i].label.match("about:")) tabs[i].image = configFav;
        if (tabs[i].label.match("Custom Buttons")) tabs[i].image = cbFav;
        if (tabs[i].label.match("forum.userstyles")) tabs[i].image = usoFav;
        if (!tabs[i].image) tabs[i].image = noFav;
      }
      if (tabImg.hasAttribute("busy")) {
        if (throbber) favImage.setAttribute("src", throbberFav);
      } else if (tabImg.image) favImage.setAttribute("src", tabImg.image);
      else favImage.setAttribute("src", noFav);
    } catch(ex) {}
  }

  setInterval(function() {loadFavs()}, 250);

})();
